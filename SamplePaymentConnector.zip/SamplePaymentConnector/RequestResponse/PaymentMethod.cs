﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SamplePaymentConnector.RequestResponse
{
    public class PaymentMethod
    {
        public PaymentMethod(string name, bool isLinkedRefundSupported, bool isUnlinkedRefundSupported)
        {
            this.Name = name;
            this.IsLinkedRefundSupported = isLinkedRefundSupported;
            this.IsUnlinkedRefundSupported = isUnlinkedRefundSupported;
        }

        public string Name { get; private set; }

        public bool IsLinkedRefundSupported { get; private set; }

        public bool IsUnlinkedRefundSupported { get; private set; }
    }
}
