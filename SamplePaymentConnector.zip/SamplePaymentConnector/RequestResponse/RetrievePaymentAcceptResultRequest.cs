
namespace SamplePaymentConnector.RequestResponse
{
    using System;
    using System.Collections.Generic;
    using Microsoft.Dynamics.Retail.PaymentSDK.Portable;
    using Microsoft.Dynamics.Retail.PaymentSDK.Portable.Constants;

    /// <summary>
    /// Request to retrieve payment accept result.
    /// </summary>
    /// <seealso cref="Microsoft.Dynamics.Retail.SampleConnector.Portable.RequestBase" />
    internal class RetrievePaymentAcceptResultRequest : RequestBase
    {
        /// <summary>
        /// Converts <see cref="Request"/> to <see cref="RetrievePaymentAcceptResultRequest"/>.
        /// </summary>
        /// <param name="request">The request.</param>
        /// <returns>An instance of <see cref="RetrievePaymentAcceptResultRequest"/>.</returns>
        internal static RetrievePaymentAcceptResultRequest ConvertFrom(Request request)
        {
            var acceptResultRequest = new RetrievePaymentAcceptResultRequest();
            var errors = new List<PaymentError>();
            acceptResultRequest.ReadBaseProperties(request, errors);

            if (errors.Count > 0)
            {
                throw new SampleException(errors);
            }

            return acceptResultRequest;
        }
    }
}
